class DoNothingYet < ActiveRecord::Migration[5.0]
  def up
  end

  def down 
  end
end
