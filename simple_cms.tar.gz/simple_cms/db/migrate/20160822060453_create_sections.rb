class CreateSections < ActiveRecord::Migration[5.0]




=begin


change method , runs the command as given when migrating up 
runs the reverse of the command when migrating down , BUT 
only works uf all the commands are reversiable . i.e 
add_column can be reversed by remove_column as it has all the info removed column needs  but remove_column 
can't be reversed as add column as it doesnt have column defination needed  for add_column .	


	
=end





  def change
    create_table :sections do |t|
     t.integer "page_id"
    t.string "name"
    	t.integer "position"
    	t.boolean "visiable" , :default=> false
    	t.string "content_type"
    	t.text "content"
      t.timestamps
    end
    add_index("sections","page_id")
  end
 
end
