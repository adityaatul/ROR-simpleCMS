class CreateUsers < ActiveRecord::Migration[5.0]
  def up
    create_table :users do |t| #{:id => false } this will supress rails from creating a default id for us .

      t.column "first_name" , :string ,:limt =>25 #adding a column , long way
      t.string "last_name" , :limt => 50 #adding a column in a short way 
      t.string "email" , :default =>"" ,:null => false
      t.string "password" , :limit =>40 
     # t.datetime "created_at"
      #t.datetime "updated_at"
      
      t.timestamps

    end
  end

  def down 
  	drop_table :users
  end
end
