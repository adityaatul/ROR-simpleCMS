class CreateAdminUsersPagesJoin < ActiveRecord::Migration[5.0]
  def up
    create_table :admin_users_pages , id=>false do |t|

    	t.integer "admin_user_id"
    	t.integer "page_id"
    end
    add_index :admin_users_pages , ["admin_user_id" , "page_id"]
  end


def down

drop_table :admin_users_pages

end

end
# for this kind of simple join we only want the foreign key , we don't want the primary key , as 
#this one is the join table , so will turn the default p. to false ;
#hence it will create a table that will have just two column , n dat is what we need , 