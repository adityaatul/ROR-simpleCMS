class Subject < ActiveRecord::Base

	has_many :pages





=begin
for now building an explicit one to one realtionship , considering that a
	 subject has_one : page 
	Page belongs_to : subject 
	Class that have belongs to is the one that will get the foreign key . 
	Allways define both side of a relationship.

	

=end

	scope :visiable , lambda { where(:visiable=>true) }
	scope :invisiable , lambda {where(:visiable=>false) }
	scope :sorted , lambda { order("subjects.position ASC")}
	
	scope :newest_first , lambda {order ("subjects.created_at DESC")}
	scope :search , lambda {|query|
 
		where(["name LIKE ?","%#{query}%"])
	 }

end
