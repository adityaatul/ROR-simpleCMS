class Post < ApplicationRecord::Base
end
