class Section < ApplicationRecord

	
	#has_many :section
	has_many :section_edits
end
