 class Page < ApplicationRecord
	belongs_to :subject 
	has_and_belongs_to_many :editors , :class_name=>"AdminUser"
	#we don't want our pages to have many admin_users , as it doesnt mean
	#anything , the better one will be a page should have many editors n thats why we chnaged the name .

	#here the belongs to is a tip that we need to have a foregin key on the page table ,
	#in whichever model file we have belongs_to it means that in its migration table we need to have
	#a foreign key relationship

scope :sorted , lambda { order("pages.position ASC")}

end
