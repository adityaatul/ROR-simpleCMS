class AdminUser < ActiveRecord::Base

	#To configure a different table name
	#self.table_name = "admin_users"
=begin

AdminUser - SectionEdit :: many to many association 
AdminUser has_many :section_edits
SectionEdits belongs_to :admin_user
Section has_many :section_edits
SectionEdits belongs_to : section 

=end

	has_secure_password

	has_and_belongs_to_many :pages
	has_many :section_edits
end
