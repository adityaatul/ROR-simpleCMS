class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception




private       #making this method private confirms that this method cannot be called as an action 
def confirm_logged_in
unless session[:user_id]
	flash[:notice] = "Please confirm log in"
	redirect_to(:controller=> 'access' , :action => 'login')
	return false 
	#redirect and halt the before action as the user isn't logged in , he needs to login in first 
	#returning false signifies the halting of rest process 
else
	return true 

end

end




end
