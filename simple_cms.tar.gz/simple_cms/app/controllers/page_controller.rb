class PageController < ApplicationController
  layout 'admin'
 before_action :confirm_logged_in 

  def index
    @page=Page.sorted
  end

  def show
    @page=Page.find(params[:id])
  end

  def new
    @page=Page.new({:name=>"default"})
  end

  def create
    @page=Page.new(params.require(:page).permit(:name , :position , :visiable ,:subject_id))
    
    
  if Subject.find_by_id(@page.subject_id)

    @page.save
      puts "in save block"
      redirect_to(:action=>'index')
    else
      puts "in else block"
      redirect_to(:controller=> 'subjects', :action=>'index')
    

    end  
  

  end

  def edit
    @page=Page.find(params[:id])

  end

  def update
@page=Page.find(params[:id])
if @page.update_attributes(params.require(:page).permit(:name , :position , :subject_id )) && Subject.find_by_id(@page.subject_id)

redirect_to(:action=>'show' ,:id=>@page.id)
else
  render('edit')

end 

  end

  def delete
    @page=Page.find(params[:id])
  end

  def destroy
     @page=Page.find(params[:id])
  @page.destroy
  redirect_to(:action=> 'index')  
  end
end
