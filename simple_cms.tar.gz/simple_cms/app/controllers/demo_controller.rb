class DemoController < ApplicationController
  def index
  	render(:template => 'demo/hello'   )
  end
  def hello 
  	render('index')
  end
  def other_hello
  	redirect_to(:controller => 'demo' , :action => 'index')
  end
end
