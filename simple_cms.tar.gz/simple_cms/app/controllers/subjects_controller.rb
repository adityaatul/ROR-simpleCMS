class SubjectsController < ApplicationController
  
  layout 'admin'

before_action :confirm_logged_in 

  def index #placeholder
@subjects = Subject.sorted

  end

  def show
    @subject = Subject.find(params[:id])
  end

  def new
#works without having the subject object , but for best practices we should allways add a varible ,
#having a variable help us to set the default values of new form 

    @subject =Subject.new({:name=>"default"})

  end

  def create
  
#Instantiate a new object using form parameters
@subject=Subject.new(params.require(:subject).permit(:name , :position , :visiable ))
#Save the object 
if @subject.save
#If save succeeds , redirect to the index action
redirect_to(:action=>'index')
else
#If save fails , redisplay the form so user can fix problems
  render('new')

end
end


  def edit
    @subject=Subject.find(params[:id])
  end


  def update
  
@subject = Subject.find(params[:id])
if @subject.update_attributes(params.require(:subject).permit(:name , :position , :visiable ))

redirect_to(:action=>'show' ,:id=>@subject.id)
else
  render('edit')

end 
end


def subject_params
#same as using "params[:subject]" , except that it :
#raises an error if :subject is not present
#allows listed attributes to be mass assigned 
params.require(:subject).permit(:name , :position , :visiable )
  
end

def destroy 
  @subject=Subject.find(params[:id])
  @subject.destroy
  redirect_to(:action=> 'index')  
end



  def delete

    @subject=Subject.find(params[:id])


  end
end
