Rails.application.routes.draw do
 
   root "demo#index"
  match ':controller(/:action(/:id))' , :via => :get
  get 'admin' , :to=>'access#index'

 

  match ':controller(/:action(/:id))' ,:via => [:get , :post]

#	resources :subjects do
#		member do
#			get :delete
#		end
#	end
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
 